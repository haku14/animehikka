const btn1 = document.querySelector(".btn1");


btn1.addEventListener("click", function(){
    console.log("1")
});


